# calculadora_imc

Calculo de IMC 

IMC = (peso / altura ²)

## Requisitos:

Python 3
